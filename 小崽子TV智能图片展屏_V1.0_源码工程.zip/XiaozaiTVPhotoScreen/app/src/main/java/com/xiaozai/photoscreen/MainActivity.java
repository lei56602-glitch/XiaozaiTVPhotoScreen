package com.xiaozai.photoscreen;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.text.format.Formatter;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

import org.json.JSONArray;
import org.json.JSONObject;
import fi.iki.elonen.NanoHTTPD;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private PhotoServer server;
    private LinearLayout root;
    private TextView status, countText;
    private ImageView qrView, photoView;
    private Handler handler = new Handler();
    private List<File> photos = new ArrayList<>();
    private int photoIndex = 0;
    private final AtomicBoolean refreshing = new AtomicBoolean(false);
    private final Runnable slideshow = new Runnable() {
        @Override public void run() {
            refreshPhotos();
            handler.postDelayed(this, 5000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        seedSamples();
        buildUi();
        startServer();
        handler.post(slideshow);
    }


    private void seedSamples() {
        File dir = new File(getFilesDir(), "photos");
        if (!dir.exists()) dir.mkdirs();
        File[] existing = dir.listFiles();
        if (existing != null && existing.length > 0) return;
        try {
            String[] names = {"sample1.jpg", "sample2.jpg", "sample3.jpg"};
            for (String name : names) {
                try (InputStream in = getAssets().open(name);
                     OutputStream out = new FileOutputStream(new File(dir, name))) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
            }
        } catch (Exception ignored) {}
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(Color.rgb(12, 16, 25));
        root.setPadding(28, 24, 28, 24);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setGravity(Gravity.CENTER);
        left.setPadding(12, 12, 24, 12);
        root.addView(left, new LinearLayout.LayoutParams(0, -1, 0.34f));

        TextView title = text("小崽子 TV 智能图片展屏", 25, Color.WHITE, true);
        left.addView(title);
        TextView hint = text("手机与电视连接同一个 Wi-Fi，微信扫码上传图片", 15, Color.LTGRAY, false);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = 16; left.addView(hint, hp);

        qrView = new ImageView(this);
        qrView.setAdjustViewBounds(true);
        qrView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(280, 280);
        qp.topMargin = 22; left.addView(qrView, qp);

        status = text("正在启动局域网上传服务…", 14, Color.WHITE, false);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 14; left.addView(status, sp);

        countText = text("图片数量：0", 14, Color.LTGRAY, false);
        countText.setGravity(Gravity.CENTER);
        left.addView(countText);

        Button refresh = new Button(this);
        refresh.setText("刷新图片");
        refresh.setOnClickListener(v -> refreshPhotos());
        left.addView(refresh);

        photoView = new ImageView(this);
        photoView.setBackgroundColor(Color.BLACK);
        photoView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(photoView, new LinearLayout.LayoutParams(0, -1, 0.66f));
        setContentView(root);
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void startServer() {
        try {
            server = new PhotoServer(8765, new File(getFilesDir(), "photos"));
            server.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
            String ip = getLanIp();
            String url = "http://" + ip + ":8765/";
            qrView.setImageBitmap(makeQr(url, 500));
            status.setText("上传地址：" + url + "\n请用微信扫码打开");
        } catch (Exception e) {
            status.setText("启动失败：" + e.getMessage() + "\n请检查电视 Wi-Fi");
        }
    }

    private String getLanIp() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                NetworkInterface ni = en.nextElement();
                for (Enumeration<InetAddress> ae = ni.getInetAddresses(); ae.hasMoreElements();) {
                    InetAddress a = ae.nextElement();
                    if (!a.isLoopbackAddress() && a instanceof Inet4Address) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }

    private Bitmap makeQr(String value, int size) throws Exception {
        BitMatrix matrix = new MultiFormatWriter().encode(value, BarcodeFormat.QR_CODE, size, size);
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565);
        for (int x=0; x<size; x++) for (int y=0; y<size; y++)
            bmp.setPixel(x, y, matrix.get(x,y) ? Color.BLACK : Color.WHITE);
        return bmp;
    }

    private void refreshPhotos() {
        if (refreshing.getAndSet(true)) return;
        new Thread(() -> {
            try {
                File dir = new File(getFilesDir(), "photos");
                File[] arr = dir.listFiles((d, n) -> {
                    String x = n.toLowerCase(Locale.ROOT);
                    return x.endsWith(".jpg") || x.endsWith(".jpeg") || x.endsWith(".png") ||
                           x.endsWith(".webp") || x.endsWith(".gif");
                });
                List<File> list = new ArrayList<>();
                if (arr != null) { Arrays.sort(arr, Comparator.comparingLong(File::lastModified)); list.addAll(Arrays.asList(arr)); }
                runOnUiThread(() -> {
                    photos = list;
                    countText.setText("图片数量：" + photos.size());
                    if (photos.isEmpty()) {
                        photoView.setImageDrawable(null);
                        photoView.setBackgroundColor(Color.rgb(20, 25, 35));
                    } else {
                        if (photoIndex >= photos.size()) photoIndex = 0;
                        File f = photos.get(photoIndex++);
                        BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inSampleSize = 2;
                        Bitmap bmp = BitmapFactory.decodeFile(f.getAbsolutePath(), opts);
                        if (bmp != null) photoView.setImageBitmap(bmp);
                    }
                    refreshing.set(false);
                });
            } catch (Exception e) { refreshing.set(false); }
        }).start();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(slideshow);
        if (server != null) server.stop();
        super.onDestroy();
    }

    private static class PhotoServer extends NanoHTTPD {
        private final File dir;
        PhotoServer(int port, File directory) throws IOException {
            super(port); dir = directory; if (!dir.exists()) dir.mkdirs();
        }
        @Override public Response serve(IHTTPSession session) {
            try {
                String uri = session.getUri();
                if (Method.GET.equals(session.getMethod()) && ("/".equals(uri) || "/index.html".equals(uri)))
                    return newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", PAGE);
                if (Method.GET.equals(session.getMethod()) && "/api/images".equals(uri)) {
                    JSONArray a = new JSONArray();
                    File[] fs = dir.listFiles();
                    if (fs != null) for (File f : fs) if (isImage(f.getName())) a.put(f.getName());
                    return newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8", a.toString());
                }
                if (Method.POST.equals(session.getMethod()) && "/api/upload".equals(uri)) {
                    Map<String,String> files = new HashMap<>();
                    session.parseBody(files);
                    String temp = files.get("postData");
                    if (temp == null) return newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/plain", "没有收到图片数据");
                    String name = session.getParms().get("name");
                    if (name == null || name.trim().isEmpty()) name = "photo_" + System.currentTimeMillis() + ".jpg";
                    name = new File(name).getName().replaceAll("[^a-zA-Z0-9._-]", "_");
                    if (!isImage(name)) name += ".jpg";
                    File out = new File(dir, System.currentTimeMillis() + "_" + name);
                    try (InputStream in = new FileInputStream(temp); OutputStream os = new FileOutputStream(out)) {
                        byte[] buf = new byte[8192]; int n;
                        while ((n=in.read(buf))>0) os.write(buf,0,n);
                    }
                    return newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8",
                        new JSONObject().put("ok", true).put("name", out.getName()).toString());
                }
                return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain; charset=utf-8", "Not found");
            } catch (Exception e) {
                return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain; charset=utf-8", "上传失败：" + e.getMessage());
            }
        }
        private boolean isImage(String n) {
            String x=n.toLowerCase(Locale.ROOT);
            return x.endsWith(".jpg") || x.endsWith(".jpeg") || x.endsWith(".png") || x.endsWith(".webp") || x.endsWith(".gif");
        }
        private static final String PAGE = "<!doctype html><html lang='zh-CN'><meta name='viewport' content='width=device-width,initial-scale=1'><meta charset='utf-8'><title>电视图片上传</title><style>body{font-family:Arial,sans-serif;background:#101827;color:#fff;margin:0;padding:24px}main{max-width:560px;margin:auto;background:#1d293b;border-radius:18px;padding:22px}h2{margin-top:0}input,button{width:100%;box-sizing:border-box;margin:12px 0;padding:14px;border-radius:10px;font-size:16px}button{border:0;background:#36a269;color:white;font-weight:bold}small{color:#b9c5d5}.bar{height:8px;background:#39465b;border-radius:8px;overflow:hidden}.bar i{display:block;height:100%;width:0;background:#36a269}</style><main><h2>上传图片到电视</h2><p>选择手机相册中的一张或多张图片，上传后电视会自动展示。</p><input id='files' type='file' accept='image/*' multiple><button onclick='upload()'>开始上传</button><div class='bar'><i id='progress'></i></div><p id='msg'>等待选择图片</p><small>请保持手机和电视连接同一个 Wi-Fi。图片只保存在电视本机。</small></main><script>async function upload(){const msg=document.getElementById('msg'),progress=document.getElementById('progress');let fs=document.getElementById('files').files;if(!fs.length){msg.textContent='请先选择图片';return}let done=0;for(let f of fs){try{let r=await fetch('/api/upload?name='+encodeURIComponent(f.name),{method:'POST',headers:{'Content-Type':f.type||'application/octet-stream'},body:f});if(!r.ok)throw Error(await r.text());done++;progress.style.width=(done/fs.length*100)+'%';msg.textContent='已上传 '+done+'/'+fs.length+'：'+f.name}catch(e){msg.textContent='上传失败：'+e.message;return}}msg.textContent='全部上传完成！电视将自动展示图片。'}</script></html>";
    }
}
